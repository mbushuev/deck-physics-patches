"""Generate Batman collision entries from the installed PhysX 2.8.1 DLL."""
import argparse
import ctypes
import hashlib
from pathlib import Path
import re
import struct

ORIGINAL = 'b35d64eb30cd51b56be92924f61d13204c3afc3c9ae712568f4baec2744ec4ab'
PTX = 'ec661bd38b47ae8e6ffdec7fdcaa02a8ea122455e970e738d33f94aaa093aa4f'
ENTRY = b'_Z29KernelDeformableUberCollisionPi'
PAPER = b'batma_cloth_paper_sweep'
TILED = b'batma_cloth_triangle_tiles'
DIRECT = b'batma_cloth_triangle_direct'
SHAPES_DIRECT = b'batma_cloth_shapes_direct'
PHYSX = 'df8d6bf07d024b8dce846a4bfcc5fdf4c42afc5e67acd43afb66cf28bfffff88'


def extract_cloth(core):
    dll = core.read_bytes()
    if hashlib.sha256(dll).hexdigest() != PHYSX:
        raise SystemExit('Expected the verified Batman PhysX 2.8.1 DLL.')
    start = 0
    while (start := dll.find(b'\x50\xed\x55\xba', start)) != -1 and start + 16 <= len(dll):
        _, version, header, size = struct.unpack_from('<IHHQ', dll, start)
        if version == 1 and header == 16 and 0 < size <= len(dll) - start - header:
            image = dll[start:start + header + size]
            if hashlib.sha256(image).hexdigest() == ORIGINAL:
                return image
        start += 4
    raise SystemExit('Could not find the verified collision module in PhysX.')


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('prefix', type=Path)
parser.add_argument('game_exe', type=Path)
args = parser.parse_args()
output = Path(__file__).resolve().parent / 'cloth'
core = args.prefix / 'pfx/drive_c/Program Files (x86)/NVIDIA Corporation/PhysX/Engine/v2.8.1/PhysXCore.dll'
image = extract_cloth(core)
pos = struct.unpack_from('<H', image, 6)[0]
while pos < len(image):
    kind, version, header, size = struct.unpack_from('<HHII', image, pos)
    if kind == 1:
        break
    pos += header + size
else:
    raise SystemExit('Missing PTX record')

compressed_size = struct.unpack_from('<I', image, pos + 16)[0]
flags, _, unpacked_size = struct.unpack_from('<QQQ', image, pos + 40)
if version != 0x101 or not flags & 0x2000:
    raise SystemExit('Unexpected PTX encoding')
lz4 = ctypes.CDLL('liblz4.so.1')
original_ptx = ctypes.create_string_buffer(unpacked_size)
data = image[pos + header:pos + header + compressed_size]
if lz4.LZ4_decompress_safe(data, original_ptx, len(data), unpacked_size) != unpacked_size:
    raise SystemExit('PTX decompression failed')
ptx = original_ptx.raw
if hashlib.sha256(ptx).hexdigest() != PTX:
    raise SystemExit('Unexpected collision PTX')

declaration = b'.entry ' + ENTRY + b'(\r\n.param .u32 ' + ENTRY + b'_param_0\r\n)\r\n'
if ptx.count(declaration) != 1 or ptx.count(b'.entry ') != 1 or not ptx.rstrip().endswith(b'}'):
    raise SystemExit('Unexpected collision entry layout')


def replace_once(body, original, replacement):
    if body.count(original) != 1:
        raise SystemExit(f'Unexpected collision instruction: {original[:60]!r}')
    return body.replace(original, replacement, 1)


def triangle_sweep(body):
    begin = body.index(b'BB15_52:\n')
    end = body.index(b'BB15_90:\n', begin)
    if hashlib.sha256(body[begin:end]).hexdigest() != '2d37b3298969a84f2f728ee5cb0521bffbd8696d30949b42faf9e6016a96bffd':
        raise SystemExit('Unexpected triangle scan')
    if body.count(b'bra BB15_52;') != 1 or body.count(b'bra BB15_53;') != 1:
        raise SystemExit('Unexpected triangle scan branches')

    def extrema(moving):
        text = ''
        for axis, value, fixed in zip('xyz', moving, (172, 173, 174)):
            text += (f'min.ftz.NaN.f32 %batma_tri_min_{axis}, %f{value}, %f{fixed};\n'
                     f'max.ftz.NaN.f32 %batma_tri_max_{axis}, %f{value}, %f{fixed};\n')
        return text.encode()

    # BB15_77 updates the carried endpoint after resolving a contact.
    for point, moving in ((b'BB15_52:\n', (169, 170, 171)),
                          (b'mov.f32 %f276, %f2090;\n', (2092, 2248, 2404))):
        body = replace_once(body, point, point + extrema(moving))
    for axis, p, moving, fixed, lower, upper in (
            ('x', 57, 192, 172, 1102, 1106),
            ('y', 63, 191, 173, 1103, 1107),
            ('z', 69, 190, 174, 1104, 1108)):
        for cmp, bound, extreme, combine, first in (
                ('lt', lower, 'max', 'and', p),
                ('leu' if axis == 'z' else 'gt', upper, 'min', 'or' if axis == 'z' else 'and', p+3)):
            second, result = first + 1, first + 2
            a, b = (second, first) if combine == 'or' else (first, second)
            old = (f'setp.{cmp}.ftz.f32\t%p{first}, %f{moving}, %f{bound};\n'
                   f'setp.{cmp}.ftz.f32\t%p{second}, %f{fixed}, %f{bound};\n'
                   f'{combine}.pred %p{result}, %p{a}, %p{b};')
            new = f'setp.{cmp}.ftz.f32 %p{result}, %batma_tri_{extreme}_{axis}, %f{bound};'
            body = replace_once(body, old.encode(), new.encode())
    registers = b'.reg .s64 %rd<34>;'
    return replace_once(body, registers, registers +
        b'\n.reg .f32 %batma_tri_min_x, %batma_tri_max_x, %batma_tri_min_y, '
        b'%batma_tri_max_y, %batma_tri_min_z, %batma_tri_max_z;')


def patch_bounds(body, paper=False):
    # Reuse the shape scan from 0038-hoist-deformable-swept-bounds.patch.
    # Preserve its ordered and unordered comparisons.
    body = body.replace(b'\r\n', b'\n')
    begin = body.index(b'BB15_17:\n')
    end = body.index(b'BB15_24:\n', begin)
    if hashlib.sha256(body[begin:end]).hexdigest() != '8037fb14ab9ac2711f1f1adb1bd60e5bcff49c5ca333f1c364f54a94811b4c71':
        raise SystemExit('Unexpected shape scan')
    sweep = b'''BB15_17:
mov.u32 %r365, 0;
min.ftz.NaN.f32 %batma_min_x, %f1785, %f1788;
max.ftz.NaN.f32 %batma_max_x, %f1785, %f1788;
min.ftz.NaN.f32 %batma_min_y, %f1786, %f1789;
max.ftz.NaN.f32 %batma_max_y, %f1786, %f1789;
min.ftz.NaN.f32 %batma_min_z, %f1787, %f1790;
max.ftz.NaN.f32 %batma_max_z, %f1787, %f1790;

BB15_18:
tex.1d.v4.f32.s32 {%f953, %f954, %f955, %f956}, [texShapeAabbMin, {%r364}];
tex.1d.v4.f32.s32 {%f957, %f958, %f959, %f960}, [texShapeAabbMax, {%r364}];
setp.lt.ftz.f32 %p29, %batma_max_x, %f953;
@%p29 bra BB15_25;
setp.gt.ftz.f32 %p32, %batma_min_x, %f957;
@%p32 bra BB15_25;
setp.lt.ftz.f32 %p35, %batma_max_y, %f954;
@%p35 bra BB15_25;
setp.gt.ftz.f32 %p38, %batma_min_y, %f958;
@%p38 bra BB15_25;
setp.lt.ftz.f32 %p41, %batma_max_z, %f955;
@%p41 bra BB15_25;
setp.leu.ftz.f32 %p44, %batma_min_z, %f959;
@!%p44 bra BB15_25;
bra.uni BB15_24;

'''
    body = body[:begin] + sweep + body[end:]
    registers = b'.reg .s64 %rd<34>;'
    if body.count(registers) != 1:
        raise SystemExit('Unexpected register declarations')
    body = body.replace(registers, registers + b'\n.reg .f32 %batma_min_x, %batma_max_x, '
                        b'%batma_min_y, %batma_max_y, %batma_min_z, %batma_max_z;')
    if paper:
        body = triangle_sweep(body)
    return body


TILE_TABLE = b'''
.visible .global .align 16 .b8 batmaTriangleTiles[262144];
.visible .global .align 4 .u32 batmaTriangleTileCount;
'''

TILE_BUILDER = b'''
.visible .entry batma_build_triangle_tiles(.param .u32 full_tiles)
{
    .reg .pred %p<2>;
    .reg .u32 %r<8>;
    .reg .f32 %f<16>;
    ld.param.u32 %r0, [full_tiles];
    mov.u32 %r1, %ctaid.x;
    mov.u32 %r2, %tid.x;
    mad.lo.u32 %r3, %r1, 128, %r2;
    setp.eq.u32 %p0, %r3, 0;
    @%p0 st.global.u32 [batmaTriangleTileCount], %r0;
    setp.ge.u32 %p0, %r3, %r0;
    @%p0 ret;
    shl.b32 %r4, %r3, 3;
    tex.1d.v4.f32.s32 {%f0, %f1, %f2, %f3}, [texTriangleAabbMin, {%r4}];
    tex.1d.v4.f32.s32 {%f4, %f5, %f6, %f7}, [texTriangleAabbMax, {%r4}];
    mov.u32 %r5, 7;
BATMA_NEXT_BOUND:
    add.u32 %r4, %r4, 1;
    tex.1d.v4.f32.s32 {%f8, %f9, %f10, %f11}, [texTriangleAabbMin, {%r4}];
    tex.1d.v4.f32.s32 {%f12, %f13, %f14, %f15}, [texTriangleAabbMax, {%r4}];
    min.ftz.NaN.f32 %f0, %f0, %f8;
    min.ftz.NaN.f32 %f1, %f1, %f9;
    min.ftz.NaN.f32 %f2, %f2, %f10;
    max.ftz.NaN.f32 %f4, %f4, %f12;
    max.ftz.NaN.f32 %f5, %f5, %f13;
    max.ftz.NaN.f32 %f6, %f6, %f14;
    sub.u32 %r5, %r5, 1;
    setp.ne.u32 %p1, %r5, 0;
    @%p1 bra BATMA_NEXT_BOUND;
    mov.u32 %r6, batmaTriangleTiles;
    mad.lo.u32 %r7, %r3, 32, %r6;
    st.global.v4.f32 [%r7], {%f0, %f1, %f2, %f3};
    st.global.v4.f32 [%r7+16], {%f4, %f5, %f6, %f7};
    ret;
}
'''


def triangle_tiles(body):
    # Use the same aligned eight-triangle rejection and carried state as
    # 0039-cull-deformable-triangle-tiles.patch.
    registers = b'.reg .s64 %rd<34>;'
    body = replace_once(body, registers, registers + b'''
.reg .pred %btp0;
.reg .u32 %btr<5>;
.reg .f32 %btf<8>;
''')
    scan = b'add.s32 %r248, %r230, %r367;\n'
    return replace_once(body, scan, scan + b'''
and.b32 %btr0, %r248, 7;
setp.ne.u32 %btp0, %btr0, 0;
@%btp0 bra BATMA_TEST_TRIANGLE;
sub.u32 %btr0, %r235, %r367;
setp.lt.u32 %btp0, %btr0, 8;
@%btp0 bra BATMA_TEST_TRIANGLE;
shr.u32 %btr1, %r248, 3;
ld.global.u32 %btr2, [batmaTriangleTileCount];
setp.ge.u32 %btp0, %btr1, %btr2;
@%btp0 bra BATMA_TEST_TRIANGLE;
mov.u32 %btr3, batmaTriangleTiles;
mad.lo.u32 %btr4, %btr1, 32, %btr3;
ld.global.v4.f32 {%btf0, %btf1, %btf2, %btf3}, [%btr4];
ld.global.v4.f32 {%btf4, %btf5, %btf6, %btf7}, [%btr4+16];
setp.lt.ftz.f32 %btp0, %batma_tri_max_x, %btf0;
setp.gt.or.ftz.f32 %btp0, %batma_tri_min_x, %btf4, %btp0;
setp.lt.or.ftz.f32 %btp0, %batma_tri_max_y, %btf1, %btp0;
setp.gt.or.ftz.f32 %btp0, %batma_tri_min_y, %btf5, %btp0;
setp.lt.or.ftz.f32 %btp0, %batma_tri_max_z, %btf2, %btp0;
setp.gt.or.ftz.f32 %btp0, %batma_tri_min_z, %btf6, %btp0;
@!%btp0 bra BATMA_TEST_TRIANGLE;
mov.f32 %f2088, %f189;
mov.f32 %f2092, %f192;
mov.f32 %f2244, %f188;
mov.f32 %f2248, %f191;
mov.f32 %f2400, %f187;
mov.f32 %f2404, %f190;
mov.f32 %f2795, %f186;
mov.f32 %f3238, %f185;
mov.f32 %f3681, %f184;
add.u32 %r367, %r367, 7;
bra BB15_89;
BATMA_TEST_TRIANGLE:
''')


def direct_triangle_reads(body):
    # Direct reads from 0269, with texture fallback for out-of-range indices.
    samples = (
        ('texTriangleAabbMin', 1102), ('texTriangleAabbMax', 1106),
        ('texTriangleOrigin', 1110), ('texTriangleEdge0', 1114), ('texTriangleEdge1', 1118),
    )
    for start, end, label in ((0, 2, 'BOUNDS'), (2, 5, 'TRIANGLE')):
        first, last = samples[start], samples[end - 1]

        def fetch(sample):
            name, register = sample
            values = ', '.join(f'%f{r}' for r in range(register, register + 4))
            return f'tex.1d.v4.f32.s32 {{{values}}}, [{name}, {{%r248}}];'.encode()

        begin = body.index(fetch(first))
        finish = body.index(fetch(last), begin) + len(fetch(last))
        original = body[begin:finish]
        if original.split() != b' '.join(map(fetch, samples[start:end])).split():
            raise SystemExit('Unexpected triangle texture sequence')
        lines = [
            'ld.param.u32 %batma_count, [batma_triangle_planes+20];',
            'setp.lt.u32 %batma_valid, %r248, %batma_count;',
            f'@!%batma_valid bra BATMA_{label}_TEXTURE;',
            'shl.b32 %batma_offset, %r248, 4;',
        ]
        for index in range(start, end):
            values = ', '.join(f'%f{r}' for r in range(samples[index][1], samples[index][1] + 4))
            lines.extend((
                f'ld.param.u32 %batma_address, [batma_triangle_planes+{4 * index}];',
                'add.u32 %batma_address, %batma_address, %batma_offset;',
                f'ld.global.v4.f32 {{{values}}}, [%batma_address];',
            ))
        lines.extend((f'bra BATMA_{label}_DONE;', f'BATMA_{label}_TEXTURE:',
                      original.decode(), f'BATMA_{label}_DONE:'))
        body = body[:begin] + '\n'.join(lines).encode() + body[finish:]
    registers = b'.reg .s64 %rd<34>;'
    return replace_once(body, registers, registers +
        b'\n.reg .pred %batma_valid;\n.reg .u32 %batma_count, %batma_offset, %batma_address;')


def direct_shape_reads(body):
    # 0270 reads four integer textures as scalars. Their other lanes are dead.
    groups = (
        ('SHAPE_BOUNDS', '%r364', (
            ('texShapeAabbMin', 'f', 953), ('texShapeAabbMax', 'f', 957),
        )),
        ('SHAPE', '%r215', (
            ('texShapePoseQ', 'f', 961), ('texShapeNewPoseQ', 'f', 965),
            ('texShapePoseP', 'f', 969), ('texShapeNewPoseP', 'f', 973),
            ('texShapeDims', 'f', 977), ('texShapeBodyID', 'r', 220),
            ('texShapeFlags', 'r', 225), ('texShapeOffsetPrimitives', 'r', 230),
            ('texShapeNumPrimitives', 'r', 235),
        )),
    )
    parameter = 'batma_triangle_planes'
    field_offset = 24
    for label, coordinate, fields in groups:
        texture_reads = []
        lines = [
            f'ld.param.u32 %batma_count, [{parameter}+68];',
            f'setp.lt.u32 %batma_valid, {coordinate}, %batma_count;',
            f'@!%batma_valid bra BATMA_{label}_TEXTURE;',
            f'shl.b32 %batma_offset, {coordinate}, 4;',
        ]
        scalar = False
        for texture, kind, first in fields:
            registers = [f'%{kind}{r}' for r in range(first, first + 4)]
            result = '{' + ', '.join(registers) + '}'
            ty = 'f32' if kind == 'f' else 'u32'
            texture_reads.append(f'tex.1d.v4.{ty}.s32 {result}, [{texture}, {{{coordinate}}}];')
            if kind == 'r':
                if any(len(re.findall(rb'(?<!\w)' + r.encode() + rb'(?!\w)', body)) != 1
                       for r in registers[1:]):
                    raise SystemExit('Unexpected use of a scalar texture lane')
                if not scalar:
                    lines.append(f'shl.b32 %batma_offset, {coordinate}, 2;')
                    scalar = True
                load = f'ld.global.u32 {registers[0]}'
            else:
                load = f'ld.global.v4.f32 {result}'
            lines.extend((f'ld.param.u32 %batma_address, [{parameter}+{field_offset}];',
                          'add.u32 %batma_address, %batma_address, %batma_offset;',
                          f'{load}, [%batma_address];'))
            field_offset += 4
        first_read, last_read = texture_reads[0].encode(), texture_reads[-1].encode()
        begin = body.index(first_read)
        end = body.index(last_read, begin) + len(last_read)
        original = body[begin:end]
        if original.split() != ' '.join(texture_reads).encode().split():
            raise SystemExit(f'Unexpected {label} texture sequence')
        lines.extend((f'bra BATMA_{label}_DONE;', f'BATMA_{label}_TEXTURE:',
                      original.decode(), f'BATMA_{label}_DONE:'))
        body = replace_once(body, original, '\n'.join(lines).encode())
    return body


start = ptx.index(declaration)
body = patch_bounds(ptx[start + len(declaration):], paper=True)
signature = declaration[len(ENTRY) + len(b'.entry '):]
modified = ptx + b'\r\n.entry ' + PAPER + signature + body.replace(b'\n', b'\r\n')
modified += (TILE_TABLE + TILE_BUILDER).replace(b'\n', b'\r\n')
tiled_body = triangle_tiles(body)
modified += b'\r\n.entry ' + TILED + signature + tiled_body.replace(b'\n', b'\r\n')
direct_signature = replace_once(signature, b'_param_0\r\n)',
    b'_param_0,\r\n.param .align 4 .b8 batma_triangle_planes[24]\r\n)')
direct_body = direct_triangle_reads(tiled_body)
modified += b'\r\n.entry ' + DIRECT + direct_signature + direct_body.replace(b'\n', b'\r\n')
shape_signature = replace_once(direct_signature, b'batma_triangle_planes[24]', b'batma_triangle_planes[72]')
shape_body = direct_shape_reads(direct_body).replace(b'\n', b'\r\n')
modified += b'\r\n.entry ' + SHAPES_DIRECT + shape_signature + shape_body

packed = ctypes.create_string_buffer(lz4.LZ4_compressBound(len(modified)))
length = lz4.LZ4_compress_default(modified, packed, len(modified), len(packed))
if length <= 0:
    raise SystemExit('PTX compression failed')
check = ctypes.create_string_buffer(len(modified))
if lz4.LZ4_decompress_safe(packed, check, length, len(check)) != len(modified) or check.raw != modified:
    raise SystemExit('PTX round-trip failed')

alignment = (length + 7) & ~7
record = bytearray(image[pos:pos + header])
struct.pack_into('<I', record, 8, alignment)
struct.pack_into('<I', record, 16, length)
struct.pack_into('<Q', record, 56, len(modified))
result = bytearray(image[:pos] + record + packed.raw[:length] + b'\0' * (alignment - length)
                   + image[pos + header + size:])
struct.pack_into('<Q', result, 8, len(result) - struct.unpack_from('<H', result, 6)[0])
output.mkdir()
(output / 'cloth-original.fatbin').write_bytes(image)
(output / 'cloth-shapes.fatbin').write_bytes(result)
(output / 'enabled').touch()
