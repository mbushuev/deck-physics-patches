#define _GNU_SOURCE
#include <dlfcn.h>
#include <pthread.h>
#include <stdint.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef int (*LoadModule)(void **module, const void *image);
typedef int (*GetFunction)(void **function, void *module, const char *name);
typedef int (*UnloadModule)(void *module);
typedef int (*ExportTable)(const void **table, const void *uuid);
typedef int (*LaunchKernel)(void *, unsigned, unsigned, unsigned, unsigned, unsigned,
                            unsigned, unsigned, void *, void **, void **);
typedef int (*SetTexAddress)(size_t *, void *, uint64_t, size_t);
typedef int (*SetTexAddress2D)(void *, const void *, uint64_t, size_t);
typedef int (*SetTexFormat)(void *, int, int);
typedef int (*SetTexFlags)(void *, unsigned);
typedef int (*SetTexArray)(void *, void *, unsigned);
static LoadModule real_load;
static GetFunction real_get_function;
static UnloadModule real_unload;
static LaunchKernel real_launch;
static ExportTable real_export_table;
static GetFunction real_get_texref;
static SetTexAddress real_set_tex_address;
static SetTexAddress2D real_set_tex_address_2d;
static SetTexFormat real_set_tex_format;
static SetTexFlags real_set_tex_flags;
static SetTexArray real_set_tex_array;
static pthread_once_t driver_once = PTHREAD_ONCE_INIT;
static pthread_mutex_t module_lock = PTHREAD_MUTEX_INITIALIZER;
static unsigned char *expected_image, *specialized_image;
static size_t expected_size, specialized_size;
static const char *alternate_name;
static const char *enable_file;
static const char *tiles_file;
static const char *direct_file;
static const char *shapes_file;
static void *specialized_module;
static void *tile_builder, *tiled_function, *direct_function, *shapes_function;
enum { max_module_globals = 32 };
static uint32_t module_globals;
static const char *const texture_names[] = {
    "texTriangleAabbMin", "texTriangleAabbMax", "texTriangleOrigin",
    "texTriangleEdge0", "texTriangleEdge1",
    "texShapeAabbMin", "texShapeAabbMax", "texShapePoseQ", "texShapeNewPoseQ",
    "texShapePoseP", "texShapeNewPoseP", "texShapeDims", "texShapeBodyID",
    "texShapeFlags", "texShapeOffsetPrimitives", "texShapeNumPrimitives",
};
enum {
    triangle_fields = 5,
    shape_float_fields = 7,
    texture_fields = sizeof(texture_names) / sizeof(texture_names[0]),
    shape_fields = texture_fields - triangle_fields,
};
static struct TextureBinding {
    void *handle;
    uint64_t address;
    size_t bytes;
    int format, components;
    unsigned flags;
} texture_bounds[texture_fields];
static _Atomic(void *) original_function;
static _Atomic(void *) alternate_function;
static atomic_uint uses;
static atomic_uint fallback;
static atomic_uint stock_uses;
static atomic_uint tile_uses;
static atomic_uint direct_uses;
static atomic_uint shapes_uses;
static atomic_int last_mode = -1;
static unsigned char *read_image(const char *path, size_t *size)
{
    if (!path)
        return NULL;
    FILE *file = fopen(path, "rb");
    if (!file)
        return NULL;
    unsigned char *data = NULL;
    if (!fseek(file, 0, SEEK_END)) {
        long length = ftell(file);
        if (length > 16 && length <= 8 * 1024 * 1024 && !fseek(file, 0, SEEK_SET)) {
            data = malloc((size_t)length);
            if (data && fread(data, 1, (size_t)length, file) == (size_t)length) {
                *size = (size_t)length;
            } else {
                free(data);
                data = NULL;
            }
        }
    }
    fclose(file);
    return data;
}

static void load_driver(void)
{
    void *driver = dlopen("libcuda.so.1", RTLD_NOW | RTLD_NOLOAD);
    if (driver) {
        real_load = (LoadModule)dlsym(driver, "cuModuleLoadData");
        real_get_function = (GetFunction)dlsym(driver, "cuModuleGetFunction");
        real_unload = (UnloadModule)dlsym(driver, "cuModuleUnload");
        real_launch = (LaunchKernel)dlsym(driver, "cuLaunchKernel");
        real_export_table = (ExportTable)dlsym(driver, "cuGetExportTable");
        real_get_texref = (GetFunction)dlsym(driver, "cuModuleGetTexRef");
        real_set_tex_address = (SetTexAddress)dlsym(driver, "cuTexRefSetAddress_v2");
        real_set_tex_address_2d = (SetTexAddress2D)dlsym(driver, "cuTexRefSetAddress2D_v3");
        real_set_tex_format = (SetTexFormat)dlsym(driver, "cuTexRefSetFormat");
        real_set_tex_flags = (SetTexFlags)dlsym(driver, "cuTexRefSetFlags");
        real_set_tex_array = (SetTexArray)dlsym(driver, "cuTexRefSetArray");
    }
    expected_image = read_image(getenv("BATMA_CLOTH_ORIGINAL"), &expected_size);
    specialized_image = read_image(getenv("BATMA_CLOTH_SPECIALIZED"), &specialized_size);
    alternate_name = getenv("BATMA_CLOTH_PAPER") ? "batma_cloth_paper_sweep" :
                     getenv("BATMA_CLOTH_BOUNDS") ? "batma_cloth_sweep_bounds" :
                                                   "batma_cloth_reqntid64";
    enable_file = getenv("BATMA_CLOTH_ENABLE_FILE");
    tiles_file = getenv("BATMA_CLOTH_TILES_FILE");
    direct_file = getenv("BATMA_CLOTH_DIRECT_FILE");
    shapes_file = getenv("BATMA_CLOTH_SHAPES_FILE");
}

static const void *const *legacy_launch_table(void)
{
    const unsigned char uuid[] = {0xee,0x37,0x6a,0x1b,0xb8,0x58,0x42,0xeb,
                                  0xa5,0x2d,0x9a,0x10,0x6d,0x50,0xd9,0x14};
    const void *entry = NULL;
    if (!real_export_table || real_export_table(&entry, uuid) || !entry)
        return NULL;
    return entry;
}

static int compatible_parameters(void *stock, void *alternate, uint32_t extra_size)
{
    const void *const *table = legacy_launch_table();
    if (!table)
        return 0;
    struct Argument { uint32_t size, align; };
    typedef int (*Arguments)(struct Argument *, uint32_t *, void *);
    Arguments arguments = (Arguments)table[1];
    uint32_t n = 0, m = 0;
    const uint32_t expected = extra_size ? 2 : 1;
    if (!arguments || arguments(NULL, &n, stock) || arguments(NULL, &m, alternate) ||
        n != 1 || m != expected)
        return 0;
    struct Argument a = {0}, b[2] = {{0}};
    return !arguments(&a, &n, stock) && !arguments(b, &m, alternate) &&
           n == 1 && m == expected && a.size == 4 && b[0].size == a.size &&
           b[0].align == a.align &&
           (!extra_size || (b[1].size == extra_size && b[1].align &&
                            b[1].align <= 4 && !(b[1].align & (b[1].align - 1))));
}

static int legacy_global_count(void *module, uint32_t *count)
{
    typedef int (*Globals)(const char **, const void **, uint32_t *, uint32_t *, uint32_t *, void *);
    const void *const *table = legacy_launch_table();
    Globals globals = table ? (Globals)table[0] : NULL;
    return globals && !globals(NULL, NULL, NULL, NULL, count, module) &&
           *count <= max_module_globals;
}

struct Wrapper {
    uint32_t magic;
    uint32_t version;
    const void *data;
    const void *extra;
};

static const unsigned char *fatbin(const void *image, size_t *size)
{
    if (!image)
        return NULL;
    const unsigned char *data = image;
    uint32_t magic;
    memcpy(&magic, data, sizeof(magic));
    if (magic == 0x466243b1) {
        const struct Wrapper *wrapper = image;
        if (wrapper->version != 1 || !wrapper->data)
            return NULL;
        data = wrapper->data;
        memcpy(&magic, data, sizeof(magic));
    }
    if (magic != 0xba55ed50)
        return NULL;
    uint16_t version, header;
    uint64_t payload;
    memcpy(&version, data + 4, sizeof(version));
    memcpy(&header, data + 6, sizeof(header));
    memcpy(&payload, data + 8, sizeof(payload));
    if (version != 1 || header < 16 || header > 256 || payload > 8 * 1024 * 1024)
        return NULL;
    *size = header + payload;
    return data;
}

int cuModuleLoadData(void **module, const void *image)
{
    pthread_once(&driver_once, load_driver);
    if (!real_load)
        return 999;
    size_t size = 0;
    const unsigned char *data = fatbin(image, &size);
    pthread_mutex_lock(&module_lock);
    if (data && expected_image && size == expected_size && !memcmp(data, expected_image, size)) {
        uint32_t magic;
        memcpy(&magic, image, sizeof(magic));
        if (magic == 0x466243b1 && specialized_size && !specialized_module) {
            struct Wrapper patched = *(const struct Wrapper *)image;
            patched.data = specialized_image;
            int result = real_load(module, &patched);
            if (!result) {
                specialized_module = *module;
                fputs("BATMA_CLOTH loaded specialized module\n", stderr);
                pthread_mutex_unlock(&module_lock);
                return result;
            }
            fprintf(stderr, "BATMA_CLOTH specialization load failed: %d\n", result);
        } else if (!specialized_image) {
            fputs("BATMA_CLOTH matched original module\n", stderr);
        }
    }
    const int result = real_load(module, image);
    pthread_mutex_unlock(&module_lock);
    return result;
}

int cuModuleGetFunction(void **function, void *module, const char *name)
{
    pthread_once(&driver_once, load_driver);
    if (!real_get_function)
        return 999;
    const int result = real_get_function(function, module, name);
    if (result || strcmp(name, "_Z29KernelDeformableUberCollisionPi"))
        return result;
    pthread_mutex_lock(&module_lock);
    if (module == specialized_module) {
        void *alternate = NULL;
        if (!real_get_function(&alternate, module, alternate_name) &&
            (!enable_file || compatible_parameters(*function, alternate, 0))) {
            atomic_store(&alternate_function, alternate);
            atomic_store(&original_function, *function);
            if (enable_file)
                fputs("BATMA_CLOTH verified alternate launch ABI\n", stderr);
            void *tiled = NULL, *builder = NULL;
            if (tiles_file &&
                !real_get_function(&tiled, module, "batma_cloth_triangle_tiles") &&
                !real_get_function(&builder, module, "batma_build_triangle_tiles") &&
                compatible_parameters(*function, tiled, 0) &&
                compatible_parameters(*function, builder, 0) &&
                legacy_global_count(module, &module_globals)) {
                tiled_function = tiled;
                tile_builder = builder;
                fputs("BATMA_CLOTH verified tile launch ABI\n", stderr);
                void *direct = NULL;
                if (direct_file &&
                    !real_get_function(&direct, module, "batma_cloth_triangle_direct") &&
                    compatible_parameters(*function, direct, 24)) {
                    direct_function = direct;
                    fputs("BATMA_CLOTH verified direct triangle launch ABI\n", stderr);
                    void *shapes = NULL;
                    if (shapes_file &&
                        !real_get_function(&shapes, module, "batma_cloth_shapes_direct") &&
                        compatible_parameters(*function, shapes, (texture_fields + 2) * sizeof(uint32_t))) {
                        shapes_function = shapes;
                        fputs("BATMA_CLOTH verified direct shape launch ABI\n", stderr);
                    }
                }
            }
        }
    }
    pthread_mutex_unlock(&module_lock);
    return result;
}

int cuModuleUnload(void *module)
{
    pthread_once(&driver_once, load_driver);
    if (!real_unload)
        return 999;
    pthread_mutex_lock(&module_lock);
    const int result = real_unload(module);
    if (!result && module == specialized_module) {
        atomic_store(&original_function, NULL);
        atomic_store(&alternate_function, NULL);
        specialized_module = NULL;
        tiled_function = tile_builder = direct_function = shapes_function = NULL;
        memset(texture_bounds, 0, sizeof(texture_bounds));
    }
    pthread_mutex_unlock(&module_lock);
    return result;
}

static struct TextureBinding *bound_for(void *handle)
{
    const unsigned fields = shapes_file ? texture_fields : triangle_fields;
    for (unsigned i = 0; i < fields; i++)
        if (handle && texture_bounds[i].handle == handle)
            return &texture_bounds[i];
    return NULL;
}

int cuModuleGetTexRef(void **texture, void *module, const char *name)
{
    pthread_once(&driver_once, load_driver);
    if (!real_get_texref)
        return 999;
    pthread_mutex_lock(&module_lock);
    const int result = real_get_texref(texture, module, name);
    if (!result && tiles_file && module == specialized_module) {
        const unsigned fields = shapes_file ? texture_fields : triangle_fields;
        for (unsigned i = 0; i < fields; i++)
            if (!strcmp(name, texture_names[i]) && texture_bounds[i].handle != *texture)
                texture_bounds[i] = (struct TextureBinding){.handle = *texture};
    }
    pthread_mutex_unlock(&module_lock);
    return result;
}

int cuTexRefSetAddress_v2(size_t *offset, void *texture, uint64_t address, size_t bytes)
{
    pthread_once(&driver_once, load_driver);
    if (!real_set_tex_address)
        return 999;
    pthread_mutex_lock(&module_lock);
    const int result = real_set_tex_address(offset, texture, address, bytes);
    struct TextureBinding *bound = bound_for(texture);
    if (bound) {
        bound->address = address;
        bound->bytes = !result && offset && !*offset && address ? bytes : 0;
    }
    pthread_mutex_unlock(&module_lock);
    return result;
}

int cuTexRefSetFormat(void *texture, int format, int components)
{
    pthread_once(&driver_once, load_driver);
    if (!real_set_tex_format)
        return 999;
    pthread_mutex_lock(&module_lock);
    const int result = real_set_tex_format(texture, format, components);
    struct TextureBinding *bound = bound_for(texture);
    if (bound) {
        bound->format = result ? 0 : format;
        bound->components = result ? 0 : components;
    }
    pthread_mutex_unlock(&module_lock);
    return result;
}

int cuTexRefSetFlags(void *texture, unsigned flags)
{
    pthread_once(&driver_once, load_driver);
    if (!real_set_tex_flags)
        return 999;
    pthread_mutex_lock(&module_lock);
    const int result = real_set_tex_flags(texture, flags);
    struct TextureBinding *bound = bound_for(texture);
    if (bound)
        bound->flags = result ? ~0u : flags;
    pthread_mutex_unlock(&module_lock);
    return result;
}

int cuTexRefSetAddress2D_v3(void *texture, const void *desc, uint64_t address, size_t pitch)
{
    pthread_once(&driver_once, load_driver);
    if (!real_set_tex_address_2d)
        return 999;
    pthread_mutex_lock(&module_lock);
    const int result = real_set_tex_address_2d(texture, desc, address, pitch);
    struct TextureBinding *bound = bound_for(texture);
    if (bound)
        bound->bytes = 0;
    pthread_mutex_unlock(&module_lock);
    return result;
}

int cuTexRefSetArray(void *texture, void *array, unsigned flags)
{
    pthread_once(&driver_once, load_driver);
    if (!real_set_tex_array)
        return 999;
    pthread_mutex_lock(&module_lock);
    const int result = real_set_tex_array(texture, array, flags);
    struct TextureBinding *bound = bound_for(texture);
    if (bound)
        bound->bytes = 0;
    pthread_mutex_unlock(&module_lock);
    return result;
}

// The table is module-local. Only the legacy default stream can build or
// consume it, so the next build cannot race the preceding collision.
static int prepare_tiles(void **collision_params)
{
    const size_t bytes = texture_bounds[0].bytes;
    if (!tile_builder || !tiled_function || bytes != texture_bounds[1].bytes ||
        bytes < 128 || bytes > 128 * 8192 || bytes % 16)
        return 0;
    for (unsigned i = 0; i < 2; i++)
        if (texture_bounds[i].format != 32 || texture_bounds[i].components != 4 ||
            texture_bounds[i].flags != 0)
            return 0;
    uint32_t count = bytes / 128;
    // The WoW64 bridge appends the arena pointer and module-global offsets.
    void *params[2 + max_module_globals] = {&count};
    memcpy(params + 1, collision_params + 1, (1 + module_globals) * sizeof(*params));
    return real_launch(tile_builder, (count + 127) / 128, 1, 1, 128, 1, 1,
                       0, NULL, params, NULL) == 0;
}

static int direct_planes(const struct TextureBinding *bounds, unsigned fields,
                         unsigned float_fields, uint64_t pool, uint32_t *planes)
{
    const size_t count = bounds[0].bytes / 16;
    for (unsigned i = 0; i < fields; i++) {
        const struct TextureBinding *bound = &bounds[i];
        const int vector = i < float_fields;
        const size_t stride = vector ? 16 : 4;
        const size_t bytes = bound->bytes;
        const uint64_t offset = bound->address - pool;
        if (!pool || !bytes || bytes > UINT32_MAX || bytes % stride || bytes / stride != count ||
            bound->address < pool || (offset % stride) || offset > UINT32_MAX - bytes ||
            bound->format != (vector ? 32 : 3) || bound->components != (vector ? 4 : 1) ||
            bound->flags != (vector ? 0u : 1u))
            return 0;
        planes[i] = offset;
    }
    planes[fields] = count;
    return 1;
}

int cuLaunchKernel(void *function, unsigned gx, unsigned gy, unsigned gz,
                   unsigned bx, unsigned by, unsigned bz, unsigned shared,
                   void *stream, void **params, void **extra)
{
    pthread_once(&driver_once, load_driver);
    if (!real_launch)
        return 999;
    if (function && function == atomic_load(&original_function)) {
        void *alternate = atomic_load(&alternate_function);
        if (alternate && bx == 64 && by == 1 && bz == 1) {
            if (enable_file) {
                int mode_id = access(enable_file, F_OK) == 0;
                int building = !stream && params && !extra && tiles_file &&
                               access(tiles_file, F_OK) == 0;
                uint32_t planes[texture_fields + 2];
                void *direct_params[3 + max_module_globals];
                void *selected = mode_id ? alternate : function;
                void **selected_params = params;
                if (building) {
                    pthread_mutex_lock(&module_lock);
                    if (function == atomic_load(&original_function) && prepare_tiles(params)) {
                        mode_id = 2;
                        selected = tiled_function;
                        uint64_t pool = 0;
                        if (params[1])
                            memcpy(&pool, params[1], sizeof(pool));
                        if (direct_function && direct_file && !access(direct_file, F_OK) &&
                            direct_planes(texture_bounds, triangle_fields, triangle_fields, pool, planes)) {
                            mode_id = 3;
                            selected = direct_function;
                            if (shapes_function && !access(shapes_file, F_OK) &&
                                direct_planes(texture_bounds + triangle_fields, shape_fields, shape_float_fields,
                                              pool, planes + triangle_fields + 1)) {
                                mode_id = 4;
                                selected = shapes_function;
                            }
                            direct_params[0] = params[0];
                            direct_params[1] = planes;
                            memcpy(direct_params + 2, params + 1,
                                   (1 + module_globals) * sizeof(*params));
                            selected_params = direct_params;
                        }
                    }
                }
                static const char *const modes[] = {"stock", "paper", "tiles", "direct", "shapes"};
                const int result = real_launch(selected, gx, gy, gz, bx, by, bz,
                                               shared, stream, selected_params, extra);
                if (building)
                    pthread_mutex_unlock(&module_lock);
                if (!result) {
                    atomic_uint *const counters[] = {&stock_uses, &uses, &tile_uses, &direct_uses, &shapes_uses};
                    atomic_uint *counter = counters[mode_id];
                    const unsigned count = atomic_fetch_add(counter, 1) + 1;
                    if (atomic_exchange(&last_mode, mode_id) != mode_id || count % 64 == 0)
                        fprintf(stderr, "BATMA_CLOTH mode=%s calls=%u grid=%u\n",
                                modes[mode_id], count, gx);
                }
                return result;
            }
            const int result = real_launch(alternate, gx, gy, gz, bx, by, bz,
                                           shared, stream, params, extra);
            if (!result && atomic_fetch_add(&uses, 1) % 128 == 0)
                fprintf(stderr, "BATMA_CLOTH used %s block=64x1x1\n", alternate_name);
            return result;
        }
        if (atomic_fetch_add(&fallback, 1) == 0)
            fputs("BATMA_CLOTH used original for another block shape\n", stderr);
    }
    return real_launch(function, gx, gy, gz, bx, by, bz, shared, stream, params, extra);
}
